package com.example.ProyectoRestauranteAS.models.service;

import com.example.ProyectoRestauranteAS.models.entity.Restaurante;

import java.util.List;

public interface IRestauranteService {
    public List<Restaurante> findAll();
    public Restaurante findById(Long id);
    public Restaurante save (Restaurante restaurante);
    public void delete (Long id);
}
