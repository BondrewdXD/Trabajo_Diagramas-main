package com.example.ProyectoRestauranteAS.models.dao;

import com.example.ProyectoRestauranteAS.models.entity.Restaurante;
import org.springframework.data.repository.CrudRepository;

public interface IRestauranteDao extends CrudRepository<Restaurante,Long> {
}
