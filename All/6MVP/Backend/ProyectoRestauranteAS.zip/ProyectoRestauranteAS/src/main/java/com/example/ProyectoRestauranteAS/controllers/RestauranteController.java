package com.example.ProyectoRestauranteAS.controllers;

import com.example.ProyectoRestauranteAS.models.entity.Restaurante;
import com.example.ProyectoRestauranteAS.models.service.IRestauranteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = {"http://localhost:4200"})
@RestController
@RequestMapping("/api")
public class RestauranteController {
    @Autowired
    private IRestauranteService restauranteService;

    @GetMapping("/restaurante")
    public List<Restaurante> index(){
        return restauranteService.findAll();
    }

    @GetMapping("/restaurante/{id}")
    public Restaurante show(@PathVariable Long id){
        return restauranteService.findById(id);
    }

    @PostMapping("/restaurante")
    @ResponseStatus(HttpStatus.CREATED)
    public Restaurante create (@RequestBody Restaurante restaurante){
        return restauranteService.save(restaurante);
    }

    @PutMapping("/restaurante/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public HttpEntity<Object> update(@RequestBody Restaurante restaurante, @PathVariable Long id){
        Optional<Restaurante> existingInventor = Optional.ofNullable(restauranteService.findById(id));
        if (!existingInventor.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();  // Si no se encuentra el inventor
        }

        Restaurante updatedRestaurante = existingInventor.get();
        updatedRestaurante.setNombreprincipio(restaurante.getNombreprincipio());
        updatedRestaurante.setNombresopa(restaurante.getNombresopa());
        updatedRestaurante.setNombrebebidas(restaurante.getNombrebebidas());
        updatedRestaurante.setNombrepostres(restaurante.getNombrepostres());
        restauranteService.save(updatedRestaurante);  // Guardar el inventor actualizado
        return ResponseEntity.ok(updatedRestaurante);
    }

    @DeleteMapping("/restaurante/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id){
        restauranteService.delete(id);
    }

}
