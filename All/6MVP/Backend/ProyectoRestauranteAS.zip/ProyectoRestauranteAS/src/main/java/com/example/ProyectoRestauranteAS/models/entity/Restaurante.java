package com.example.ProyectoRestauranteAS.models.entity;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name="restaurante")
public class Restaurante implements Serializable {
    private static final long serialVersionUID=1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMesa;

    private String nombresopa;
    private String descripcionsopa;
    private int preciosopa;

    private String nombreprincipio;
    private String descripcionprincipio;
    private int precioprincipio;

    private String nombrepostres;
    private String descripcionpostres;
    private int preciopostres;

    private String nombrebebidas;
    private String descripcionbebidas;
    private int preciobebidas;

    public Long getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(Long idMesa) {
        this.idMesa = idMesa;
    }

    public String getNombresopa() {
        return nombresopa;
    }

    public void setNombresopa(String nombresopa) {
        this.nombresopa = nombresopa;
    }

    public String getDescripcionsopa() {
        return descripcionsopa;
    }

    public void setDescripcionsopa(String descripcionsopa) {
        this.descripcionsopa = descripcionsopa;
    }

    public int getPreciosopa() {
        return preciosopa;
    }

    public void setPreciosopa(int preciosopa) {
        this.preciosopa = preciosopa;
    }

    public String getNombreprincipio() {
        return nombreprincipio;
    }

    public void setNombreprincipio(String nombreprincipio) {
        this.nombreprincipio = nombreprincipio;
    }

    public String getDescripcionprincipio() {
        return descripcionprincipio;
    }

    public void setDescripcionprincipio(String descripcionprincipio) {
        this.descripcionprincipio = descripcionprincipio;
    }

    public int getPrecioprincipio() {
        return precioprincipio;
    }

    public void setPrecioprincipio(int precioprincipio) {
        this.precioprincipio = precioprincipio;
    }

    public String getNombrepostres() {
        return nombrepostres;
    }

    public void setNombrepostres(String nombrepostres) {
        this.nombrepostres = nombrepostres;
    }

    public String getDescripcionpostres() {
        return descripcionpostres;
    }

    public void setDescripcionpostres(String descripcionpostres) {
        this.descripcionpostres = descripcionpostres;
    }

    public int getPreciopostres() {
        return preciopostres;
    }

    public void setPreciopostres(int preciopostres) {
        this.preciopostres = preciopostres;
    }

    public String getNombrebebidas() {
        return nombrebebidas;
    }

    public void setNombrebebidas(String nombrebebidas) {
        this.nombrebebidas = nombrebebidas;
    }

    public String getDescripcionbebidas() {
        return descripcionbebidas;
    }

    public void setDescripcionbebidas(String descripcionbebidas) {
        this.descripcionbebidas = descripcionbebidas;
    }

    public int getPreciobebidas() {
        return preciobebidas;
    }

    public void setPreciobebidas(int preciobebidas) {
        this.preciobebidas = preciobebidas;
    }
}
