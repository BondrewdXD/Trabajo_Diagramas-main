package com.example.ProyectoRestauranteAS.models.service;

import com.example.ProyectoRestauranteAS.models.dao.IRestauranteDao;
import com.example.ProyectoRestauranteAS.models.entity.Restaurante;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class RestauranteServiceImpl implements IRestauranteService{
    @Autowired
    private IRestauranteDao restauranteDao;

    @Override
    @Transactional(readOnly = true)
    public List<Restaurante> findAll() {
        return (List<Restaurante>) restauranteDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Restaurante findById(Long id) {
        return restauranteDao.findById(id).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public Restaurante save(Restaurante restaurante) {
        return restauranteDao.save(restaurante);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        restauranteDao.deleteById(id);
    }
}
