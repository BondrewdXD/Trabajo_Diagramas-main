import { Component } from '@angular/core';

@Component({
  selector: 'app-domicilios',
  standalone: true,
  imports: [],
  templateUrl: './domicilios.component.html',
  styleUrl: './domicilios.component.css'
})
export class DomiciliosComponent {

}
