import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Postres } from './postres';
import { POSTRES } from './postres.json';

@Component({
  selector: 'app-postres',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './postres.component.html',
  styleUrl: './postres.component.css'
})
export class PostresComponent implements OnInit{
  
  title='Menú de Postres'

  repository:Postres[];

  ngOnInit(): void {
    this.repository=POSTRES;
  }

}
