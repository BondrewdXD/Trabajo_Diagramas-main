import { Postres } from "./postres"

export const POSTRES : Postres[]=[
    {
        "nombrepostres":"Tarta de chocolate",
        "descripcionpostres":"Dulce tarta de chocolate",
        "preciopostres":5500
    }
]