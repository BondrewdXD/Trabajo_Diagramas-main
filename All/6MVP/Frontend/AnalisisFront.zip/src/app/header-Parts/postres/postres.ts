export class Postres {
    nombrepostres:string
    descripcionpostres:string
    preciopostres:number
}
