import { Component, OnInit } from '@angular/core';
import { Bebidas } from './bebidas';
import { BEBIDAS } from './bebidas.json';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-bebida',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bebida.component.html',
  styleUrl: './bebida.component.css'
})
export class BebidaComponent implements OnInit{
  
  title='Menú de Bebidas'

  repository:Bebidas[];

  ngOnInit(): void {
    this.repository=BEBIDAS;
  }


}
