export class Bebidas {
    nombrebebidas:string
    descripcionbebidas:string
    preciobebidas:number
}
