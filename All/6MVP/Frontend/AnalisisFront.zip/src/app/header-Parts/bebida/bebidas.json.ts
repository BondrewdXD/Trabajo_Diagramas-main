import { Bebidas } from "./bebidas";

export const BEBIDAS : Bebidas[]=[
    {
        "nombrebebidas":"Cerezada",
        "descripcionbebidas":"Refrescante sabor cereza",
        "preciobebidas":9000
    }
]