import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Sopas } from './sopas';
import { RouterModule } from '@angular/router';
import { SOPAS } from './sopas.json';

@Component({
  selector: 'app-sopa',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sopa.component.html',
  styleUrl: './sopa.component.css'
})
export class SopaComponent implements OnInit{
  
  title='Menú de Sopas'

  repository:Sopas[];
  
  ngOnInit(): void {
    this.repository = SOPAS;
  }

}
