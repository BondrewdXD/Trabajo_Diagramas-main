export class Sopas {
    nombresopa:string
    descripcionsopa:string
    preciosopa:number
}
