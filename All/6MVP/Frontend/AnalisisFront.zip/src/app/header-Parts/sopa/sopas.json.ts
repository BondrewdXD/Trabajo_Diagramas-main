import { Sopas } from "./sopas";

export const SOPAS : Sopas[]=[
    {
        "nombresopa":"Sopa de tomate",
        "descripcionsopa":"Sopa de tomate con chips de papa",
        "preciosopa":15000
    }
]