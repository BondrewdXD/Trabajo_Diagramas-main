import { Principios } from "./principios";

export const PRINCIPIOS : Principios[]=[
    {
        "nombreprincipio":"Salmon con soya",
        "descripcionprincipio":"Acompañado con arroz y ensalada",
        "precioprincipio":15000
    }
]