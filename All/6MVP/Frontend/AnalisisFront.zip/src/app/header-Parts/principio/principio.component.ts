import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Principios } from './principios';
import { PRINCIPIOS } from './principios.json';

@Component({
  selector: 'app-principio',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './principio.component.html',
  styleUrl: './principio.component.css'
})
export class PrincipioComponent implements OnInit{

  title='Menu de Principios'

  repository:Principios[];
  
  ngOnInit(): void {
    this.repository=PRINCIPIOS
  }


}
