export class Principios {
    nombreprincipio:string
    descripcionprincipio:string
    precioprincipio:number
}
