import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from "./header/header.component";
import { SopaComponent } from './header-Parts/sopa/sopa.component';
import { PrincipioComponent } from './header-Parts/principio/principio.component';
import { PostresComponent } from './header-Parts/postres/postres.component';
import { BebidaComponent } from './header-Parts/bebida/bebida.component';
import { DomiciliosComponent } from "./domicilios/domicilios.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, SopaComponent, PrincipioComponent, PostresComponent, BebidaComponent, DomiciliosComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Restaurantefrontend';
}
