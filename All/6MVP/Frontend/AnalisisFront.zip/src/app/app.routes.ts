import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { SopaComponent } from './header-Parts/sopa/sopa.component';
import { PrincipioComponent } from './header-Parts/principio/principio.component';
import { PostresComponent } from './header-Parts/postres/postres.component'
import { BebidaComponent } from './header-Parts/bebida/bebida.component';
import { DomiciliosComponent } from './domicilios/domicilios.component';

export const routes: Routes = [
    { path: '', redirectTo: '/principio', pathMatch: 'full' },
    {path: 'header', component: HeaderComponent},
    {path: 'sopa', component: SopaComponent},
    {path: 'principio', component: PrincipioComponent},
    {path: 'postres', component: PostresComponent},
    {path: 'bebida', component: BebidaComponent},
    {path: 'domicilio', component: DomiciliosComponent}
];
